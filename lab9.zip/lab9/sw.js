var lab="mycache";
var assets=[
    "/",
    "/index.html",
    "/sw.js",
    "/images432.png",
    "/images216.png",
    "/images108.png",
    "/manifest.json"
];

async function fetchdata(){
    const response = await fetch("https://api.github.com/users/KushwahaAnupam",
    
    {
        header:
        {
            "Authentication" : "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", 
        }
    }
    
)
    return response.json();
}

self.addEventListener("install",_event=>{
    caches.open(lab);
    then(caches =>{
        caches.addAll(assets);
    });
});

self.addEventListener("activate",_event=>{
console.log("Inside activate");
});

self.addEventListener("fetch",async event=>{
    const result = await fetchdata();
    console.log(result) 
    console.log("inside fetch")
});